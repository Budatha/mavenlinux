package flipkart1.services;

public interface MyService {

	String ask(String question);
}
